package com;

public class Usuario {
	
	private String nombre;
    private String password;
    private double peso;
    private double altura;

    public Usuario(String nombre, String password, double peso, double altura) {
        this.nombre = nombre;
        this.password = password;
        this.peso = peso;
        this.altura = altura;
    }
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPassword() {
        return password;
    }

    public void setApellido(String password) {
        this.password = password;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

}
